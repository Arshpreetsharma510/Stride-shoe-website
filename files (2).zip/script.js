/* =============================================
   STRÏDE — Premium Footwear | script.js
   ============================================= */

'use strict';

/* ---- HELPERS ---- */
const $ = (id) => document.getElementById(id);
const $$ = (sel, ctx = document) => ctx.querySelectorAll(sel);

/* =============================================
   1. NAVBAR — Scroll behaviour + mobile toggle
   ============================================= */
const navbar = $('navbar');
const mobileNav = $('mobileNav');
let mobileNavOpen = false;

window.addEventListener('scroll', () => {
  if (window.scrollY > 60) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }

  // Back to top
  const btn = $('backToTop');
  if (window.scrollY > 400) btn.classList.add('show');
  else btn.classList.remove('show');
});

// Mobile menu toggle via hamburger
$('hamburgerBtn').addEventListener('click', () => {
  mobileNavOpen = !mobileNavOpen;
  mobileNav.classList.toggle('open', mobileNavOpen);
});

// Close mobile nav on link click
$$('a', mobileNav).forEach(link => {
  link.addEventListener('click', () => {
    mobileNavOpen = false;
    mobileNav.classList.remove('open');
  });
});

/* =============================================
   2. SMOOTH SCROLL for all anchor links
   ============================================= */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    const target = document.querySelector(this.getAttribute('href'));
    if (!target) return;
    e.preventDefault();
    const offset = 72; // navbar height
    const top = target.getBoundingClientRect().top + window.scrollY - offset;
    window.scrollTo({ top, behavior: 'smooth' });
  });
});

/* =============================================
   3. SEARCH BAR toggle
   ============================================= */
const searchBar = $('searchBar');
$('searchToggle').addEventListener('click', () => {
  searchBar.classList.toggle('open');
  if (searchBar.classList.contains('open')) {
    searchBar.querySelector('input').focus();
  }
});

// Close search when clicking outside
document.addEventListener('click', (e) => {
  if (!searchBar.contains(e.target) && e.target.id !== 'searchToggle') {
    searchBar.classList.remove('open');
  }
});

/* =============================================
   4. SIDEBAR
   ============================================= */
const sidebar = $('sidebar');
const overlay = $('sidebarOverlay');

function openSidebar() {
  sidebar.classList.add('open');
  overlay.classList.add('active');
  document.body.style.overflow = 'hidden';
}
function closeSidebar() {
  sidebar.classList.remove('open');
  overlay.classList.remove('active');
  document.body.style.overflow = '';
}

// Open via the logo/hamburger — repurpose hamburger to also open sidebar on desktop
$('hamburgerBtn').addEventListener('click', openSidebar);
$('sidebarClose').addEventListener('click', closeSidebar);
overlay.addEventListener('click', closeSidebar);

// Close sidebar links
$$('a', sidebar).forEach(link => {
  link.addEventListener('click', closeSidebar);
});

/* =============================================
   5. CART COUNTER
   ============================================= */
let cartCount = 0;
const cartCountEl = $('cartCount');

function updateCart(name, price) {
  cartCount++;
  cartCountEl.textContent = cartCount;
  cartCountEl.classList.add('show');

  // Bounce animation on cart icon
  cartCountEl.animate([
    { transform: 'scale(1.8)', background: '#e2c99a' },
    { transform: 'scale(1)',   background: '#c9a96e' }
  ], { duration: 350, easing: 'ease-out' });

  // Toast notification
  showToast(`"${name}" added to cart — ₹${price.toLocaleString('en-IN')}`);
}

function showToast(msg) {
  // Remove existing toast
  const old = document.querySelector('.toast');
  if (old) old.remove();

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `<i class="fa fa-check-circle"></i> ${msg}`;
  toast.style.cssText = `
    position: fixed;
    bottom: 90px;
    right: 28px;
    background: #1a1815;
    border: 1px solid #c9a96e;
    color: #f5f0e8;
    padding: 14px 22px;
    border-radius: 6px;
    font-size: 0.85rem;
    z-index: 3000;
    display: flex;
    align-items: center;
    gap: 10px;
    box-shadow: 0 8px 30px rgba(0,0,0,0.5);
    animation: slideInToast 0.35s ease forwards;
  `;

  // Inject keyframe if not present
  if (!document.querySelector('#toastStyle')) {
    const style = document.createElement('style');
    style.id = 'toastStyle';
    style.textContent = `
      @keyframes slideInToast {
        from { opacity:0; transform: translateY(12px); }
        to   { opacity:1; transform: translateY(0); }
      }
      .toast i { color: #c9a96e; }
    `;
    document.head.appendChild(style);
  }

  document.body.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transition = 'opacity 0.3s';
    setTimeout(() => toast.remove(), 350);
  }, 3000);
}

// Attach add-to-cart buttons
$$('.add-to-cart').forEach(btn => {
  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    const name = btn.dataset.name;
    const price = parseInt(btn.dataset.price, 10);
    updateCart(name, price);

    // Ripple effect
    const ripple = document.createElement('span');
    ripple.style.cssText = `
      position:absolute; border-radius:50%;
      background:rgba(255,255,255,0.35);
      width:80px; height:80px;
      top:50%; left:50%;
      transform:translate(-50%,-50%) scale(0);
      animation: ripple 0.55s ease-out;
      pointer-events:none;
    `;
    if (!document.querySelector('#rippleStyle')) {
      const rs = document.createElement('style');
      rs.id = 'rippleStyle';
      rs.textContent = `@keyframes ripple { to { transform:translate(-50%,-50%) scale(2.5); opacity:0; } }`;
      document.head.appendChild(rs);
    }
    btn.style.position = 'relative';
    btn.appendChild(ripple);
    setTimeout(() => ripple.remove(), 600);
  });
});

/* =============================================
   6. COUNTDOWN TIMER
   ============================================= */
// Set end date to 3 days from now
const endDate = new Date();
endDate.setDate(endDate.getDate() + 3);
endDate.setHours(23, 59, 59, 999);

function updateTimer() {
  const now = new Date();
  let diff = endDate - now;

  if (diff <= 0) {
    ['days','hours','minutes','seconds'].forEach(id => { $(id).textContent = '00'; });
    return;
  }

  const days    = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours   = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((diff % (1000 * 60)) / 1000);

  const pad = n => String(n).padStart(2, '0');

  $('days').textContent    = pad(days);
  $('hours').textContent   = pad(hours);
  $('minutes').textContent = pad(minutes);
  $('seconds').textContent = pad(seconds);
}

updateTimer();
setInterval(updateTimer, 1000);

/* =============================================
   7. TESTIMONIAL SLIDER
   ============================================= */
const track = $('testimonialTrack');
const dotsContainer = $('sliderDots');
const cards = $$('.testimonial-card', track);
const totalCards = cards.length;
let currentSlide = 0;
let slidesVisible = 2; // default desktop

function getSlidesVisible() {
  return window.innerWidth <= 640 ? 1 : 2;
}

function buildDots() {
  dotsContainer.innerHTML = '';
  const totalDots = totalCards - getSlidesVisible() + 1;
  for (let i = 0; i < totalDots; i++) {
    const dot = document.createElement('div');
    dot.className = 'dot' + (i === currentSlide ? ' active' : '');
    dot.addEventListener('click', () => goToSlide(i));
    dotsContainer.appendChild(dot);
  }
}

function goToSlide(index) {
  slidesVisible = getSlidesVisible();
  const maxIndex = totalCards - slidesVisible;
  currentSlide = Math.max(0, Math.min(index, maxIndex));

  // Calculate offset
  const cardWidth = cards[0].offsetWidth + 28; // gap = 28px
  track.style.transform = `translateX(-${currentSlide * cardWidth}px)`;

  // Update dots
  $$('.dot', dotsContainer).forEach((dot, i) => {
    dot.classList.toggle('active', i === currentSlide);
  });
}

$('prevBtn').addEventListener('click', () => goToSlide(currentSlide - 1));
$('nextBtn').addEventListener('click', () => goToSlide(currentSlide + 1));

// Auto-slide every 5 seconds
let autoSlide = setInterval(() => {
  const maxIndex = totalCards - getSlidesVisible();
  goToSlide(currentSlide >= maxIndex ? 0 : currentSlide + 1);
}, 5000);

// Reset on manual interaction
[$('prevBtn'), $('nextBtn')].forEach(btn => {
  btn.addEventListener('click', () => {
    clearInterval(autoSlide);
    autoSlide = setInterval(() => {
      const maxIndex = totalCards - getSlidesVisible();
      goToSlide(currentSlide >= maxIndex ? 0 : currentSlide + 1);
    }, 5000);
  });
});

buildDots();

// Rebuild on resize
window.addEventListener('resize', () => {
  buildDots();
  goToSlide(0);
});

/* =============================================
   8. SCROLL REVEAL ANIMATIONS
   ============================================= */
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target;
      const delay = el.dataset.delay || 0;
      setTimeout(() => {
        el.classList.add('visible');
      }, parseInt(delay));
      revealObserver.unobserve(el);
    }
  });
}, {
  threshold: 0.12,
  rootMargin: '0px 0px -40px 0px'
});

$$('.reveal').forEach(el => revealObserver.observe(el));

/* =============================================
   9. CONTACT FORM VALIDATION
   ============================================= */
const form = $('contactForm');
const popup = $('successPopup');

function validate(id, errorId, condition) {
  const input = $(id);
  const group = input.closest('.form-group');
  const valid = condition(input.value.trim());
  group.classList.toggle('error', !valid);
  return valid;
}

form.addEventListener('submit', (e) => {
  e.preventDefault();

  const nameOk  = validate('formName',  'nameError',  v => v.length >= 2);
  const emailOk = validate('formEmail', 'emailError', v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v));
  const msgOk   = validate('formMsg',   'msgError',   v => v.length >= 10);

  if (nameOk && emailOk && msgOk) {
    popup.classList.add('show');
    form.reset();
    $$('.form-group', form).forEach(g => g.classList.remove('error'));
  }
});

// Live validation on input
['formName','formEmail','formMsg'].forEach(id => {
  $(id).addEventListener('input', () => {
    const group = $(id).closest('.form-group');
    if (group.classList.contains('error')) {
      group.classList.remove('error');
    }
  });
});

$('popupClose').addEventListener('click', () => {
  popup.classList.remove('show');
});

// Close popup on backdrop click
popup.addEventListener('click', (e) => {
  if (e.target === popup) popup.classList.remove('show');
});

/* =============================================
   10. BACK TO TOP
   ============================================= */
$('backToTop').addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

/* =============================================
   11. CATEGORY CARDS — click interaction
   ============================================= */
$$('.cat-card').forEach(card => {
  card.addEventListener('click', () => {
    const name = card.querySelector('h3').textContent;
    showToast(`Browsing ${name} collection…`);
    // Scroll to products
    const target = document.querySelector('#products');
    const top = target.getBoundingClientRect().top + window.scrollY - 72;
    window.scrollTo({ top, behavior: 'smooth' });
  });
});

/* =============================================
   12. CART BUTTON — show cart summary
   ============================================= */
$('cartBtn').addEventListener('click', () => {
  if (cartCount === 0) {
    showToast('Your cart is empty — start shopping! 👟');
  } else {
    showToast(`You have ${cartCount} item${cartCount > 1 ? 's' : ''} in your cart.`);
  }
});

/* =============================================
   INIT
   ============================================= */
// Trigger initial scroll check
window.dispatchEvent(new Event('scroll'));
